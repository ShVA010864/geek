a = 7;
b = 5
print(a, b)
value = a + b
print(value)
value = "Test"
print(value)

username = input("Здравствуйте. Как вас зовут: ")
age = int(input("Сколько вам лет: "))

print(f"Привет, {username}! Тебе уже {age} лет!")

print("Привет, {}! Тебе уже {} лет!".format(username, age))
